#include "Transform.h"

Transform::Transform() 
{
}


Transform::~Transform()
{
}

void Transform::tick(double dTime) {

}